import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.text.SimpleDateFormat;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class CustomerService extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JButton btnRefresh;
    private JButton btnDelete;
    private JButton btnView;
    private JButton btnBack;
    private final SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

    public CustomerService() {
        setTitle("Customer Service - Messages");
        setSize(900, 520);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());
        
        // === Header Panel ===
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(66, 133, 244));
        header.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        btnBack = new JButton("← Back");
        btnBack.setBackground(Color.WHITE);
        btnBack.setForeground(new Color(66, 133, 244));
        btnBack.setFocusPainted(false);
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.addActionListener(e -> {
            new admin().setVisible(true);
            dispose();
            // 🔹 replace this with your actual previous frame if needed, e.g.:
            // new AdminDashboard().setVisible(true);
        });

        JLabel lblTitle = new JLabel("Customer Feedback", JLabel.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);

        header.add(btnBack, BorderLayout.WEST);
        header.add(lblTitle, BorderLayout.CENTER);
        add(header, BorderLayout.NORTH);

        initUI();
        loadMessages();
    }

    private void initUI() {
        model = new DefaultTableModel(new String[]{"ID", "Guest Name", "Message (preview)", "Rating", "Date Sent"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        table.getColumnModel().getColumn(0).setMinWidth(50);
        table.getColumnModel().getColumn(0).setMaxWidth(80);

        JScrollPane sp = new JScrollPane(table);
        sp.setBorder(BorderFactory.createTitledBorder("Customer Feedback"));

        // Buttons panel
        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        btnRefresh = new JButton("Refresh");
        btnView = new JButton("View Full Message");
        btnDelete = new JButton("Delete Selected");

        buttons.add(btnView);
        buttons.add(btnRefresh);
        buttons.add(btnDelete);

        add(sp, BorderLayout.CENTER);
        add(buttons, BorderLayout.SOUTH);

        // Actions
        btnRefresh.addActionListener(e -> loadMessages());
        btnDelete.addActionListener(e -> deleteSelectedMessage());
        btnView.addActionListener(e -> viewSelectedMessage());
    }

    private void loadMessages() {
        model.setRowCount(0);
        String sql = "SELECT id, guest_name, message, rating, date_sent FROM customer_feedback ORDER BY date_sent DESC";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                int id = rs.getInt("id");
                String name = rs.getString("guest_name");
                String msg = rs.getString("message");
                String preview = msg == null ? "" : (msg.length() > 80 ? msg.substring(0, 80) + "..." : msg);
                int rating = rs.getInt("rating");
                Timestamp ts = rs.getTimestamp("date_sent");
                String date = ts == null ? "" : df.format(ts);

                model.addRow(new Object[]{id, name, preview, rating, date});
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error loading messages: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void viewSelectedMessage() {
        int sel = table.getSelectedRow();
        if (sel == -1) {
            JOptionPane.showMessageDialog(this, "Select a message to view.");
            return;
        }
        int modelRow = table.convertRowIndexToModel(sel);
        int id = (int) model.getValueAt(modelRow, 0);

        String sql = "SELECT guest_name, message, rating, date_sent FROM customer_feedback WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql)) {
            pst.setInt(1, id);
            try (ResultSet rs = pst.executeQuery()) {
                if (rs.next()) {
                    String name = rs.getString("guest_name");
                    String message = rs.getString("message");
                    int rating = rs.getInt("rating");
                    Timestamp ts = rs.getTimestamp("date_sent");
                    String date = ts == null ? "" : df.format(ts);

                    JTextArea ta = new JTextArea(10, 60);
                    ta.setLineWrap(true);
                    ta.setWrapStyleWord(true);
                    ta.setEditable(false);
                    ta.setText("From: " + name + "\nRating: " + rating + "\nDate: " + date + "\n\nMessage:\n" + message);
                    ta.setCaretPosition(0);

                    JScrollPane sp = new JScrollPane(ta);
                    JOptionPane.showMessageDialog(this, sp, "Full Message (ID: " + id + ")", JOptionPane.INFORMATION_MESSAGE);
                } else {
                    JOptionPane.showMessageDialog(this, "Message not found.");
                }
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error retrieving message: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void deleteSelectedMessage() {
        int sel = table.getSelectedRow();
        if (sel == -1) {
            JOptionPane.showMessageDialog(this, "Select a message to delete.");
            return;
        }
        int modelRow = table.convertRowIndexToModel(sel);
        int id = (int) model.getValueAt(modelRow, 0);

        int ok = JOptionPane.showConfirmDialog(this, "Delete selected message (ID: " + id + ")?", "Confirm Delete", JOptionPane.YES_NO_OPTION);
        if (ok != JOptionPane.YES_OPTION) return;

        String sql = "DELETE FROM customer_feedback WHERE id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql)) {
            pst.setInt(1, id);
            int affected = pst.executeUpdate();
            if (affected > 0) {
                JOptionPane.showMessageDialog(this, "Message deleted.");
                loadMessages();
            } else {
                JOptionPane.showMessageDialog(this, "Delete failed - message not found.");
            }
        } catch (SQLException ex) {
            JOptionPane.showMessageDialog(this, "Error deleting message: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
        }
    }

    // quick test main
    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new CustomerService().setVisible(true));
    }
}
    