import javax.swing.*;
import java.awt.*;
import java.sql.*;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.io.*;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;// ✅ Added for file handling

public class RoomDetailsDialog extends JDialog {
    private Connection con;
    private int roomId;
    private String roomNumber, roomType, description, imagePath, username;
    private double price;
    private BookRooms parent;

    private JDateChooser dateCheckIn, dateCheckOut;
    private JComboBox<String> paymentMethod;
    private JTextField txtEwallet;

    public RoomDetailsDialog(BookRooms parent, String username, int id, String roomNumber, String roomType, double price, String description, String imagePath) {
        this.parent = parent;
        this.username = username;
        this.roomId = id;
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.price = price;
        this.description = description;
        this.imagePath = imagePath;

        con = DBConnection.getConnection();

        setTitle("Room Details - " + roomNumber);
        setSize(750, 750);
        setResizable(false);
        setModal(true);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());

        // === Info Panel ===
        JPanel infoPanel = new JPanel(new BorderLayout());
        infoPanel.setBackground(Color.WHITE);
        infoPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JLabel lblImage = new JLabel();
        lblImage.setHorizontalAlignment(JLabel.CENTER);
        lblImage.setPreferredSize(new Dimension(400, 250));

        try {
            Image img = new ImageIcon(imagePath).getImage();
            Image scaled = img.getScaledInstance(400, 250, Image.SCALE_SMOOTH);
            lblImage.setIcon(new ImageIcon(scaled));
        } catch (Exception e) {
            lblImage.setText("No Image Available");
        }

        JTextArea txtDetails = new JTextArea("Room Type: " + roomType +
                                            "\nRoom No: " + roomNumber +
                                            "\nPrice: ₱" + price +
                                            "\n\nDescription:\n" + description);
        txtDetails.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        txtDetails.setEditable(false);
        txtDetails.setBackground(new Color(245, 245, 245));

        infoPanel.add(lblImage, BorderLayout.NORTH);
        infoPanel.add(txtDetails, BorderLayout.CENTER);

        // === Booking Panel ===
        JPanel bookingPanel = new JPanel(new GridLayout(6, 2, 10, 10));
        bookingPanel.setBorder(BorderFactory.createEmptyBorder(10, 20, 10, 20));

        JLabel lblCheckIn = new JLabel("Check-In Date:");
        JLabel lblCheckOut = new JLabel("Check-Out Date:");
        JLabel lblPayment = new JLabel("Payment Method:");
        JLabel lblEwallet = new JLabel("E-Wallet Number:");

        dateCheckIn = new JDateChooser();
        dateCheckOut = new JDateChooser();
        dateCheckIn.setDateFormatString("yyyy-MM-dd");
        dateCheckOut.setDateFormatString("yyyy-MM-dd");
        dateCheckIn.getJCalendar().setMinSelectableDate(new java.util.Date());
        dateCheckOut.getJCalendar().setMinSelectableDate(new java.util.Date());

        paymentMethod = new JComboBox<>(new String[]{"Cash on Hand", "E-Wallet"});
        txtEwallet = new JTextField();
        txtEwallet.setEnabled(false);

        paymentMethod.addActionListener(e -> {
            txtEwallet.setEnabled(paymentMethod.getSelectedItem().equals("E-Wallet"));
        });

        JButton btnBook = new JButton("Book Now");
        btnBook.setBackground(new Color(66, 133, 244));
        btnBook.setForeground(Color.WHITE);
        btnBook.addActionListener(e -> bookRoom());

        bookingPanel.add(lblCheckIn);
        bookingPanel.add(dateCheckIn);
        bookingPanel.add(lblCheckOut);
        bookingPanel.add(dateCheckOut);
        bookingPanel.add(lblPayment);
        bookingPanel.add(paymentMethod);
        bookingPanel.add(lblEwallet);
        bookingPanel.add(txtEwallet);
        bookingPanel.add(new JLabel());
        bookingPanel.add(btnBook);

        add(infoPanel, BorderLayout.CENTER);
        add(bookingPanel, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void bookRoom() {
        try {
            String checkIn = ((JTextField) dateCheckIn.getDateEditor().getUiComponent()).getText();
            String checkOut = ((JTextField) dateCheckOut.getDateEditor().getUiComponent()).getText();
            String payment = paymentMethod.getSelectedItem().toString();
            String ewallet = txtEwallet.getText().trim();

            if (checkIn.isEmpty() || checkOut.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Please select both Check-In and Check-Out dates!");
                return;
            }

            if (payment.equals("E-Wallet") && (ewallet.isEmpty() || !ewallet.matches("\\d{11,}"))) {
                JOptionPane.showMessageDialog(this, "Please enter a valid E-Wallet number!");
                return;
            }

            String sql = "INSERT INTO guest_reservations "
                       + "(username, room_id, room_number, room_type, checkin_date, checkout_date, payment_method, ewallet_number, total_amount, status) "
                       + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

            PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setString(1, username);
            pst.setInt(2, roomId);
            pst.setString(3, roomNumber);
            pst.setString(4, roomType);
            pst.setString(5, checkIn);
            pst.setString(6, checkOut);
            pst.setString(7, payment);
            pst.setString(8, ewallet);
            pst.setDouble(9, price);
            pst.setString(10, "Booked");

            pst.executeUpdate();
            pst.close();

            JOptionPane.showMessageDialog(this, "Room booked successfully!");

            // ✅ Generate automatic receipt after booking
            generateReceipt(checkIn, checkOut, payment, ewallet);

            dispose();
            parent.dispose();
            new BookRooms(username).setVisible(true);

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error booking room: " + e.getMessage());
        }
    }

    // ✅ NEW METHOD: Automatically download .txt receipt
    private void generateReceipt(String checkIn, String checkOut, String payment, String ewallet) {
        try {
            String timestamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new java.util.Date());
            String fileName = "receipt_" + username + "_" + timestamp + ".txt";

            // Save to user's Downloads folder
            String userHome = System.getProperty("user.home");
            File downloadsDir = new File(userHome, "Downloads");
            if (!downloadsDir.exists()) downloadsDir.mkdirs();

            File file = new File(downloadsDir, fileName);

            try (BufferedWriter writer = new BufferedWriter(new FileWriter(file))) {
                writer.write("============== UGATON HOTEL RECEIPT ==============\n");
                writer.write("Guest Username: " + username + "\n");
                writer.write("Room Number: " + roomNumber + "\n");
                writer.write("Room Type: " + roomType + "\n");
                writer.write("Check-In Date: " + checkIn + "\n");
                writer.write("Check-Out Date: " + checkOut + "\n");
                writer.write("Payment Method: " + payment + "\n");
                if (payment.equals("E-Wallet")) writer.write("E-Wallet No: " + ewallet + "\n");
                writer.write("Total Price: ₱" + price + "\n");
                writer.write("Status: Booked\n");
                writer.write("Date of Booking: " + new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(new java.util.Date()) + "\n");
                writer.write("===================================================\n");
                writer.write("Thank you for booking with us!\n");
            }

            JOptionPane.showMessageDialog(this,
                    "Receipt saved successfully!\nLocation: " + file.getAbsolutePath(),
                    "Receipt Generated", JOptionPane.INFORMATION_MESSAGE);

        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error generating receipt: " + ex.getMessage());
        }
    }
}
