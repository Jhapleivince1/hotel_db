import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.time.LocalDate;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class GuestFeedback extends JFrame {
    private Connection con;
    private JTextArea txtMessage;
    private JComboBox<Integer> cmbRating;
    private JButton btnSend;
    private String username;

    public GuestFeedback(String username) { // ✅ accept username
        this.username = username;
        con = DBConnection.getConnection();

        setTitle("Customer Service / Feedback");
        setSize(550, 430);
        setLocationRelativeTo(null);
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        // === Header (Back Button + Title) ===
        JPanel header = new JPanel(new BorderLayout());
        header.setBackground(new Color(66, 133, 244));
        header.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnBack = new JButton("← Back");
        btnBack.setBackground(Color.WHITE);
        btnBack.setForeground(new Color(66, 133, 244));
        btnBack.setFocusPainted(false);
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btnBack.addActionListener(e -> {
            new GuestDashboard(username).setVisible(true);
            dispose();
        });

        JLabel lblTitle = new JLabel("Rate Your Stay & Leave Feedback", JLabel.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);

        header.add(btnBack, BorderLayout.WEST);
        header.add(lblTitle, BorderLayout.CENTER);
        add(header, BorderLayout.NORTH);

        // === Form Panel ===
        JPanel formPanel = new JPanel(new GridLayout(5, 1, 10, 10));
        formPanel.setBorder(BorderFactory.createEmptyBorder(20, 50, 20, 50));

        JLabel lblUser = new JLabel("Logged in as: " + username);
        lblUser.setFont(new Font("Segoe UI", Font.BOLD, 13));

        txtMessage = new JTextArea(6, 20);
        txtMessage.setLineWrap(true);
        txtMessage.setWrapStyleWord(true);
        JScrollPane scroll = new JScrollPane(txtMessage);
        scroll.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);

        cmbRating = new JComboBox<>(new Integer[]{1, 2, 3, 4, 5});
        cmbRating.setSelectedIndex(4);

        formPanel.add(lblUser);
        formPanel.add(new JLabel("Your Message:"));
        formPanel.add(scroll);
        formPanel.add(new JLabel("Rating (1 - 5):"));
        formPanel.add(cmbRating);

        add(formPanel, BorderLayout.CENTER);

        // === Footer ===
        JPanel footer = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 15));
        footer.setBackground(new Color(245, 245, 245));

        btnSend = new JButton("Send Feedback");
        btnSend.setBackground(new Color(66, 133, 244));
        btnSend.setForeground(Color.WHITE);
        btnSend.setFocusPainted(false);
        btnSend.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSend.addActionListener(e -> sendFeedback());

        footer.add(btnSend);
        add(footer, BorderLayout.SOUTH);

        setVisible(true);
    }

    private void sendFeedback() {
        String message = txtMessage.getText().trim();
        int rating = (int) cmbRating.getSelectedItem();

        if (message.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please enter your feedback message!");
            return;
        }

        try {
            String sql = "INSERT INTO customer_feedback (guest_name, message, rating, date_sent) VALUES (?, ?, ?, ?)";
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setString(1, username); // ✅ use logged-in username instead of typed name
            pst.setString(2, message);
            pst.setInt(3, rating);
            pst.setDate(4, java.sql.Date.valueOf(LocalDate.now()));
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Thank you for your feedback!");
            txtMessage.setText("");
            cmbRating.setSelectedIndex(4);

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error sending feedback: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        new GuestFeedback("testUser");
    }
}