import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class GuestSettings extends JFrame {

    private JTextField txtUsername, txtFirst, txtMiddle, txtLast;
    private JPasswordField txtPass, txtConfirm;
    private JButton btnSave, btnBack;
    private String currentUsername;

    public GuestSettings(String username) {
        this.currentUsername = username;
        setTitle("Guest Account Settings");
        setSize(600, 450);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(null);
        setResizable(false);
        getContentPane().setBackground(new Color(245, 245, 245));

        JLabel lblTitle = new JLabel("Account Settings");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 26));
        lblTitle.setBounds(180, 25, 300, 30);
        add(lblTitle);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setBounds(120, 90, 100, 25);
        add(lblUsername);
        txtUsername = createTextField(230, 90);
        txtUsername.setEditable(false);
        add(txtUsername);

        JLabel lblFirst = new JLabel("First Name:");
        lblFirst.setBounds(120, 130, 100, 25);
        add(lblFirst);
        txtFirst = createTextField(230, 130);
        add(txtFirst);

        JLabel lblMiddle = new JLabel("Middle Name:");
        lblMiddle.setBounds(120, 170, 100, 25);
        add(lblMiddle);
        txtMiddle = createTextField(230, 170);
        add(txtMiddle);

        JLabel lblLast = new JLabel("Last Name:");
        lblLast.setBounds(120, 210, 100, 25);
        add(lblLast);
        txtLast = createTextField(230, 210);
        add(txtLast);

        JLabel lblPass = new JLabel("New Password:");
        lblPass.setBounds(120, 250, 120, 25);
        add(lblPass);
        txtPass = createPasswordField(230, 250);

        JCheckBox showPass = new JCheckBox("Show");
        showPass.setBounds(490, 250, 70, 25);
        showPass.setBackground(new Color(245, 245, 245));
        showPass.addActionListener(e -> {
            if (showPass.isSelected()) txtPass.setEchoChar((char) 0);
            else txtPass.setEchoChar('•');
        });
        add(txtPass);
        add(showPass);

        JLabel lblConfirm = new JLabel("Confirm Password:");
        lblConfirm.setBounds(120, 290, 130, 25);
        add(lblConfirm);
        txtConfirm = createPasswordField(230, 290);

        JCheckBox showConfirm = new JCheckBox("Show");
        showConfirm.setBounds(490, 290, 70, 25);
        showConfirm.setBackground(new Color(245, 245, 245));
        showConfirm.addActionListener(e -> {
            if (showConfirm.isSelected()) txtConfirm.setEchoChar((char) 0);
            else txtConfirm.setEchoChar('•');
        });
        add(txtConfirm);
        add(showConfirm);

        btnSave = new JButton("Save Changes");
        btnSave.setBounds(150, 350, 140, 35);
        btnSave.setBackground(new Color(0, 123, 255));
        btnSave.setForeground(Color.WHITE);
        btnSave.setFocusPainted(false);
        btnSave.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnSave.addActionListener(e -> updateAccount());
        add(btnSave);

        btnBack = new JButton("Back");
        btnBack.setBounds(310, 350, 140, 35);
        btnBack.setBackground(new Color(108, 117, 125));
        btnBack.setForeground(Color.WHITE);
        btnBack.setFocusPainted(false);
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnBack.addActionListener(e -> {
            dispose();
            new GuestDashboard(currentUsername).setVisible(true);
        });
        add(btnBack);

        loadAccountDetails();
    }

    private JTextField createTextField(int x, int y) {
        JTextField tf = new JTextField();
        tf.setBounds(x, y, 250, 28);
        tf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        tf.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1, true));
        return tf;
    }

    private JPasswordField createPasswordField(int x, int y) {
        JPasswordField pf = new JPasswordField();
        pf.setBounds(x, y, 250, 28);
        pf.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        pf.setBorder(BorderFactory.createLineBorder(Color.GRAY, 1, true));
        pf.setEchoChar('•');
        return pf;
    }

    private void loadAccountDetails() {
        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel_db", "root", "");
             PreparedStatement pst = (PreparedStatement) con.prepareStatement("SELECT * FROM user WHERE username=?")) {

            pst.setString(1, currentUsername);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                txtUsername.setText(rs.getString("username"));
                txtFirst.setText(rs.getString("firstname"));
                txtMiddle.setText(rs.getString("middlename"));
                txtLast.setText(rs.getString("lastname"));
            }

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading details: " + e.getMessage());
        }
    }

    private void updateAccount() {
        String first = txtFirst.getText();
        String middle = txtMiddle.getText();
        String last = txtLast.getText();
        String pass = new String(txtPass.getPassword());
        String confirm = new String(txtConfirm.getPassword());

        if (first.isEmpty() || last.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill out all required fields.");
            return;
        }

        if (!pass.equals(confirm)) {
            JOptionPane.showMessageDialog(this, "Passwords do not match!");
            return;
        }

        try (Connection con = DriverManager.getConnection("jdbc:mysql://localhost/hotel_db", "root", "");
             PreparedStatement pst = (PreparedStatement) con.prepareStatement(
                     "UPDATE user SET firstname=?, middlename=?, lastname=?, password=? WHERE username=?")) {

            pst.setString(1, first);
            pst.setString(2, middle);
            pst.setString(3, last);
            pst.setString(4, pass);
            pst.setString(5, currentUsername);
            pst.executeUpdate();

            JOptionPane.showMessageDialog(this, "Account updated successfully!");

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating account: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new GuestSettings("guest1").setVisible(true));
    }
}
