import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;
public class ArchivedReservations extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private Connection con;
    private String username;

    public ArchivedReservations(String username) {
        this.username = username;
        con = DBConnection.getConnection();

        setTitle("Archived Reservations - " + username);
        setSize(950, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("Archived Reservations", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        model = new DefaultTableModel(new String[]{
                "ID", "Room No", "Room Type", "Check-In", "Check-Out",
                "Payment", "E-Wallet", "Amount (₱)", "Status", "Date Booked", "Archived At"
        }, 0);

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(table);

        JButton btnBack = new JButton("Close");
        btnBack.setBackground(new Color(220, 53, 69));
        btnBack.setForeground(Color.WHITE);
        btnBack.addActionListener(e -> dispose());

        JPanel bottom = new JPanel();
        bottom.add(btnBack);

        add(lblTitle, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottom, BorderLayout.SOUTH);

        loadArchivedReservations();
    }

    private void loadArchivedReservations() {
        try {
            model.setRowCount(0);
            String sql = "SELECT * FROM archived_reservations WHERE username = ?";
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("room_number"),
                        rs.getString("room_type"),
                        rs.getString("checkin_date"),
                        rs.getString("checkout_date"),
                        rs.getString("payment_method"),
                        rs.getString("ewallet_number"),
                        rs.getDouble("total_amount"),
                        rs.getString("status"),
                        rs.getString("created_at"),
                        rs.getString("archived_at")
                });
            }

            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No archived reservations found for " + username);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading archives: " + e.getMessage());
        }
    }
}