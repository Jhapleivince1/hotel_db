import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class AdminSettings extends JFrame {
    private JTextField txtUsername;
    private JPasswordField txtPassword;
    private JButton btnSave, btnBack;
    private Connection con;

    public AdminSettings() {
        setTitle("Admin Settings");
        setSize(500, 350);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        // Connect to DB
        try {
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost/hotel_db", "root", "");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Database connection failed: " + e.getMessage());
        }

        JPanel panel = new JPanel(new GridBagLayout());
        panel.setBackground(new Color(0, 153, 153));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);

        JLabel lblTitle = new JLabel("ADMIN SETTINGS");
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setForeground(Color.WHITE);

        JLabel lblUsername = new JLabel("Username:");
        lblUsername.setForeground(Color.WHITE);
        JLabel lblPassword = new JLabel("Password:");
        lblPassword.setForeground(Color.WHITE);

        txtUsername = new JTextField(20);
        txtPassword = new JPasswordField(20);

        btnSave = new JButton("Save Changes");
        btnBack = new JButton("Back");

        btnSave.setBackground(new Color(0, 102, 102));
        btnSave.setForeground(Color.WHITE);
        btnBack.setBackground(new Color(153, 0, 0));
        btnBack.setForeground(Color.WHITE);

        gbc.gridx = 0; gbc.gridy = 0; gbc.gridwidth = 2;
        panel.add(lblTitle, gbc);

        gbc.gridwidth = 1; gbc.anchor = GridBagConstraints.LINE_END;
        gbc.gridx = 0; gbc.gridy = 1;
        panel.add(lblUsername, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;
        panel.add(txtUsername, gbc);

        gbc.gridx = 0; gbc.gridy = 2; gbc.anchor = GridBagConstraints.LINE_END;
        panel.add(lblPassword, gbc);
        gbc.gridx = 1; gbc.anchor = GridBagConstraints.LINE_START;

        // password + show checkbox container
        JPanel passPanel = new JPanel(new FlowLayout(FlowLayout.LEFT, 5, 0));
        passPanel.setOpaque(false);
        passPanel.add(txtPassword);

        JCheckBox chkShow = new JCheckBox("Show");
        chkShow.setOpaque(false);
        chkShow.setForeground(Color.WHITE);
        chkShow.addActionListener(e -> {
            if (chkShow.isSelected()) {
                txtPassword.setEchoChar((char) 0); // show password
            } else {
                txtPassword.setEchoChar('•'); // mask password (use bullet)
            }
        });
        passPanel.add(chkShow);

        panel.add(passPanel, gbc);

        gbc.gridx = 0; gbc.gridy = 3; gbc.gridwidth = 2;
        panel.add(btnSave, gbc);
        gbc.gridy = 4;
        panel.add(btnBack, gbc);

        add(panel);

        // Load current admin info
        loadAdminData();

        // Save button
        btnSave.addActionListener(e -> updateAdminData());

        // Back button
        btnBack.addActionListener(e -> {
            new admin().setVisible(true);
            dispose();
        });

        // ensure default echo char set (some LAFs might default differently)
        txtPassword.setEchoChar('•');
    }

    private void loadAdminData() {
        try {
            Statement st = con.createStatement();
            ResultSet rs = st.executeQuery("SELECT username, password FROM admins WHERE id = 1");
            if (rs.next()) {
                txtUsername.setText(rs.getString("username"));
                txtPassword.setText(rs.getString("password"));
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error loading admin info: " + e.getMessage());
        }
    }

    private void updateAdminData() {
        String user = txtUsername.getText();
        String pass = new String(txtPassword.getPassword());

        if (user.isEmpty() || pass.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Please fill in all fields.");
            return;
        }

        try {
            PreparedStatement pst = (PreparedStatement) con.prepareStatement("UPDATE admins SET username=?, password=? WHERE id=1");
            pst.setString(1, user);
            pst.setString(2, pass);
            pst.executeUpdate();
            JOptionPane.showMessageDialog(this, "Admin info updated successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Error updating admin info: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminSettings().setVisible(true));
    }
}
