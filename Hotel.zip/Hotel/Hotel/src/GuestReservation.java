import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import com.toedter.calendar.JDateChooser;
import java.text.SimpleDateFormat;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class GuestReservation extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private Connection con;
    private String username;

    public GuestReservation(String username) {
        this.username = username;
        con = DBConnection.getConnection();

        setTitle("My Reservations - " + username);
        setSize(950, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BorderLayout());

        JLabel lblTitle = new JLabel("My Reservations", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 22));
        lblTitle.setBorder(BorderFactory.createEmptyBorder(10, 0, 10, 0));

        // === Table ===
        model = new DefaultTableModel(new String[]{
                "ID", "Room No", "Room Type", "Check-In", "Check-Out",
                "Payment", "E-Wallet", "Amount (₱)", "Status", "Date Booked"
        }, 0);

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(25);

        JScrollPane scrollPane = new JScrollPane(table);

        // === Buttons ===
        JPanel btnPanel = new JPanel();
        JButton btnRefresh = new JButton("Refresh");
        JButton btnEdit = new JButton("Edit Dates");
        JButton btnCancel = new JButton("Cancel Reservation");
        JButton btnArchives = new JButton("View Archives");
        JButton btnBack = new JButton("Back");

        btnRefresh.setBackground(new Color(66, 133, 244));
        btnEdit.setBackground(new Color(0, 123, 255));
        btnCancel.setBackground(new Color(255, 193, 7));
        btnArchives.setBackground(new Color(40, 167, 69));
        btnBack.setBackground(new Color(220, 53, 69));

        btnRefresh.setForeground(Color.WHITE);
        btnEdit.setForeground(Color.WHITE);
        btnCancel.setForeground(Color.BLACK);
        btnArchives.setForeground(Color.WHITE);
        btnBack.setForeground(Color.WHITE);

        btnPanel.add(btnRefresh);
        btnPanel.add(btnEdit);
        btnPanel.add(btnCancel);
        btnPanel.add(btnArchives);
        btnPanel.add(btnBack);

        // === Actions ===
        btnRefresh.addActionListener(e -> loadReservations());
        btnCancel.addActionListener(e -> cancelSelectedReservation());
        btnBack.addActionListener(e -> {
            dispose();
            new GuestDashboard(username).setVisible(true);
        });
        btnArchives.addActionListener(e -> new ArchivedReservations(username).setVisible(true));
        btnEdit.addActionListener(e -> editReservationDates()); // ✅ new feature

        add(lblTitle, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(btnPanel, BorderLayout.SOUTH);

        loadReservations();
    }

    // === LOAD DATA ===
    private void loadReservations() {
        try {
            model.setRowCount(0);
            String sql = "SELECT * FROM guest_reservations WHERE username = ?";
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
            pst.setString(1, username);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getString("room_number"),
                        rs.getString("room_type"),
                        rs.getString("checkin_date"),
                        rs.getString("checkout_date"),
                        rs.getString("payment_method"),
                        rs.getString("ewallet_number"),
                        rs.getDouble("total_amount"),
                        rs.getString("status"),
                        rs.getString("created_at")
                });
            }

            if (model.getRowCount() == 0) {
                JOptionPane.showMessageDialog(this, "No reservations found for " + username);
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading reservations: " + e.getMessage());
        }
    }

    // === CANCEL RESERVATION ===
    private void cancelSelectedReservation() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a reservation to cancel.");
            return;
        }

        int confirm = JOptionPane.showConfirmDialog(this,
            "Are you sure you want to cancel this reservation?",
            "Confirm Cancellation",
            JOptionPane.YES_NO_OPTION);

        if (confirm == JOptionPane.YES_OPTION) {
            try {
                int id = (int) model.getValueAt(selectedRow, 0);

                // Get full data first
                String selectSql = "SELECT * FROM guest_reservations WHERE id = ? AND username = ?";
                PreparedStatement selectPst = (PreparedStatement) con.prepareStatement(selectSql);
                selectPst.setInt(1, id);
                selectPst.setString(2, username);
                ResultSet rs = selectPst.executeQuery();

                if (rs.next()) {
                    // Move to archive
                    String insertSql = "INSERT INTO archived_reservations " +
                        "(username, room_number, room_type, checkin_date, checkout_date, " +
                        "payment_method, ewallet_number, total_amount, status, created_at) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                    PreparedStatement insertPst = (PreparedStatement) con.prepareStatement(insertSql);
                    insertPst.setString(1, rs.getString("username"));
                    insertPst.setString(2, rs.getString("room_number"));
                    insertPst.setString(3, rs.getString("room_type"));
                    insertPst.setString(4, rs.getString("checkin_date"));
                    insertPst.setString(5, rs.getString("checkout_date"));
                    insertPst.setString(6, rs.getString("payment_method"));
                    insertPst.setString(7, rs.getString("ewallet_number"));
                    insertPst.setDouble(8, rs.getDouble("total_amount"));
                    insertPst.setString(9, "Cancelled");
                    insertPst.setString(10, rs.getString("created_at"));
                    insertPst.executeUpdate();

                    // Delete from main table
                    String deleteSql = "DELETE FROM guest_reservations WHERE id = ? AND username = ?";
                    PreparedStatement deletePst = (PreparedStatement) con.prepareStatement(deleteSql);
                    deletePst.setInt(1, id);
                    deletePst.setString(2, username);
                    deletePst.executeUpdate();

                    JOptionPane.showMessageDialog(this, "Reservation cancelled and archived successfully.");
                    loadReservations();
                } else {
                    JOptionPane.showMessageDialog(this, "Reservation not found.");
                }

            } catch (SQLException e) {
                JOptionPane.showMessageDialog(this, "Error cancelling reservation: " + e.getMessage());
            }
        }
    }

    // === EDIT RESERVATION DATES ===
    private void editReservationDates() {
        int selectedRow = table.getSelectedRow();

        if (selectedRow == -1) {
            JOptionPane.showMessageDialog(this, "Please select a reservation to edit.");
            return;
        }

        int id = (int) model.getValueAt(selectedRow, 0);
        String oldCheckIn = model.getValueAt(selectedRow, 3).toString();
        String oldCheckOut = model.getValueAt(selectedRow, 4).toString();

        // Create dialog
        JDialog editDialog = new JDialog(this, "Edit Reservation Dates", true);
        editDialog.setSize(400, 250);
        editDialog.setLocationRelativeTo(this);
        editDialog.setLayout(new GridLayout(4, 2, 10, 10));

        JLabel lblCheckIn = new JLabel("New Check-In Date:");
        JLabel lblCheckOut = new JLabel("New Check-Out Date:");
        JDateChooser dateCheckIn = new JDateChooser();
        JDateChooser dateCheckOut = new JDateChooser();
        dateCheckIn.setDateFormatString("yyyy-MM-dd");
        dateCheckOut.setDateFormatString("yyyy-MM-dd");
        dateCheckIn.getJCalendar().setMinSelectableDate(new java.util.Date());
        dateCheckOut.getJCalendar().setMinSelectableDate(new java.util.Date());

        JButton btnSave = new JButton("Save Changes");
        JButton btnCancel = new JButton("Cancel");

        editDialog.add(lblCheckIn);
        editDialog.add(dateCheckIn);
        editDialog.add(lblCheckOut);
        editDialog.add(dateCheckOut);
        editDialog.add(new JLabel());
        editDialog.add(new JLabel());
        editDialog.add(btnSave);
        editDialog.add(btnCancel);

        btnSave.addActionListener(e -> {
            String newCheckIn = ((JTextField) dateCheckIn.getDateEditor().getUiComponent()).getText();
            String newCheckOut = ((JTextField) dateCheckOut.getDateEditor().getUiComponent()).getText();

            if (newCheckIn.isEmpty() || newCheckOut.isEmpty()) {
                JOptionPane.showMessageDialog(editDialog, "Please select both dates.");
                return;
            }

            try {
                String updateSql = "UPDATE guest_reservations SET checkin_date = ?, checkout_date = ? WHERE id = ? AND username = ?";
                PreparedStatement pst = (PreparedStatement) con.prepareStatement(updateSql);
                pst.setString(1, newCheckIn);
                pst.setString(2, newCheckOut);
                pst.setInt(3, id);
                pst.setString(4, username);
                pst.executeUpdate();

                JOptionPane.showMessageDialog(editDialog, "Reservation dates updated successfully!");
                editDialog.dispose();
                loadReservations();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(editDialog, "Error updating reservation: " + ex.getMessage());
            }
        });

        btnCancel.addActionListener(e -> editDialog.dispose());
        editDialog.setVisible(true);
    }

    public static void main(String[] args) {
        new GuestReservation("sampleUser").setVisible(true);
    }
}
