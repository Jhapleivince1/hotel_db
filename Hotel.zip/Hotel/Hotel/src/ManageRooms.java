 import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.*;
import java.nio.file.*;
import java.sql.*;
import java.util.UUID;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class ManageRooms extends JFrame {
    private DefaultTableModel model;
    private JTable table;

    public ManageRooms() {
        setTitle("🏨 Manage Rooms");
        setSize(950, 550);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        initUI();
        setResizable(false);
        loadRooms();
    }

    private void initUI() {
        // 🌈 Main background panel
        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(240, 245, 255));
        add(mainPanel);

        // 🎨 Top Button Bar
        model = new DefaultTableModel(new String[]{"id", "Room #", "Type", "Price", "Status", "Description", "Image"}, 0) {
            public boolean isCellEditable(int r, int c) {
                return false;
            }
        };
        table = new JTable(model);
        table.removeColumn(table.getColumnModel().getColumn(0));

        // 🎨 Beautify Table
        JTableHeader header = table.getTableHeader();
        header.setFont(new Font("Segoe UI", Font.BOLD, 14));
        header.setBackground(new Color(0, 102, 204));
        header.setForeground(Color.WHITE);

        table.setRowHeight(25);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 13));
        table.setSelectionBackground(new Color(173, 216, 255));
        table.setSelectionForeground(Color.BLACK);
        table.setGridColor(new Color(220, 220, 220));

        JButton btnRefresh = styledButton("Refresh", new Color(0, 123, 255));
        JButton btnAdd = styledButton("Add Room", new Color(40, 167, 69));
        JButton btnEdit = styledButton("Edit Selected", new Color(255, 193, 7));
        JButton btnDelete = styledButton("Delete Selected", new Color(220, 53, 69));
        JButton btnPreview = styledButton("Preview Image", new Color(102, 16, 242));
        JButton btnBack = styledButton("Back", new Color(108, 117, 125));

        btnRefresh.addActionListener(e -> loadRooms());
        btnAdd.addActionListener(e -> addRoom());
        btnEdit.addActionListener(e -> editRoom());
        btnDelete.addActionListener(e -> deleteRoom());
        btnPreview.addActionListener(e -> previewImage());
        btnBack.addActionListener(e -> {
            dispose();
            new admin().setVisible(true);
        });

        JPanel top = new JPanel(new FlowLayout(FlowLayout.CENTER, 10, 10));
        top.setBackground(new Color(230, 240, 255));
        top.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(0, 102, 204), 2),
                "Room Controls",
                0, 0,
                new Font("Segoe UI", Font.BOLD, 16),
                new Color(0, 102, 204)
        ));

        top.add(btnRefresh);
        top.add(btnAdd);
        top.add(btnEdit);
        top.add(btnDelete);
        top.add(btnPreview);
        top.add(btnBack);

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(BorderFactory.createTitledBorder(
                BorderFactory.createLineBorder(new Color(0, 153, 255), 2),
                "Room List",
                0, 0,
                new Font("Segoe UI", Font.BOLD, 16),
                new Color(0, 102, 204)
        ));

        mainPanel.add(top, BorderLayout.NORTH);
        mainPanel.add(scroll, BorderLayout.CENTER);
    }

    // 🎨 Helper method to style buttons
    private JButton styledButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 13));
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 14, 8, 14));
        btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(color.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(color);
            }
        });
        return btn;
    }

    private void loadRooms() {
        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT id, room_number, room_type, price, status, description, image_path FROM rooms";
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
            ResultSet rs = pst.executeQuery();

            DefaultTableModel model = (DefaultTableModel) table.getModel();
            model.setRowCount(0);

            while (rs.next()) {
                Object[] row = {
                        rs.getInt("id"),
                        rs.getString("room_number"),
                        rs.getString("room_type"),
                        rs.getDouble("price"),
                        rs.getString("status"),
                        rs.getString("description"),
                        rs.getString("image_path")
                };
                model.addRow(row);
            }

            rs.close();
            pst.close();
            con.close();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading rooms: " + e.getMessage());
        }
    }
        private void addRoom() {
    // auto-generate next room number
    String nextRoomNo = "1";
    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = (PreparedStatement) con.prepareStatement("SELECT room_number FROM rooms ORDER BY id DESC LIMIT 1");
         ResultSet rs = pst.executeQuery()) {
        if (rs.next()) {
            int lastNo = Integer.parseInt(rs.getString("room_number"));
            nextRoomNo = String.valueOf(lastNo + 1);
        }
    } catch (Exception e) {
        nextRoomNo = "1";
    }

    JTextField fRoomNo = new JTextField(nextRoomNo);
    fRoomNo.setEditable(false);

    JComboBox<String> fType = new JComboBox<>(new String[]{"Suite", "Standard", "Deluxe"});
    JTextField fPrice = new JTextField();
    JTextArea fDesc = new JTextArea(4, 20);
    JComboBox<String> fStatus = new JComboBox<>(new String[]{"Available", "Booked", "Unavailable"});

    // auto price logic
    fType.addActionListener(e -> {
        String type = (String) fType.getSelectedItem();
        switch (type) {
            case "Suite": fPrice.setText("5000"); break;
            case "Standard": fPrice.setText("2500"); break;
            case "Deluxe": fPrice.setText("3500"); break;
        }
    });

    JButton btnChooseImage = new JButton("🎨 Choose Image");
    JLabel imgLabel = new JLabel("No image selected");
    final File[] chosenFile = new File[1];

    btnChooseImage.addActionListener(e -> {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files", ImageIO.getReaderFileSuffixes()));
        int ok = fc.showOpenDialog(this);
        if (ok == JFileChooser.APPROVE_OPTION) {
            chosenFile[0] = fc.getSelectedFile();
            imgLabel.setText(chosenFile[0].getName());
        }
    });

    // 🎨 Create colorful panel for design
    JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));
    panel.setBackground(new Color(250, 250, 255));
    panel.setBorder(BorderFactory.createTitledBorder(
        BorderFactory.createLineBorder(new Color(0, 102, 204), 2),
        "Add New Room",
        0, 0,
        new Font("Segoe UI", Font.BOLD, 18),
        new Color(0, 102, 204)
    ));

    Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
    Color labelColor = new Color(50, 50, 80);

    JLabel lblRoom = new JLabel("Room #:");
    lblRoom.setForeground(labelColor); lblRoom.setFont(labelFont);
    JLabel lblType = new JLabel("Type:");
    lblType.setForeground(labelColor); lblType.setFont(labelFont);
    JLabel lblPrice = new JLabel("Price:");
    lblPrice.setForeground(labelColor); lblPrice.setFont(labelFont);
    JLabel lblStatus = new JLabel("Status:");
    lblStatus.setForeground(labelColor); lblStatus.setFont(labelFont);
    JLabel lblDesc = new JLabel("Description:");
    lblDesc.setForeground(labelColor); lblDesc.setFont(labelFont);

    panel.add(lblRoom); panel.add(fRoomNo);
    panel.add(lblType); panel.add(fType);
    panel.add(lblPrice); panel.add(fPrice);
    panel.add(lblStatus); panel.add(fStatus);
    panel.add(lblDesc); panel.add(new JScrollPane(fDesc));
    panel.add(btnChooseImage); panel.add(imgLabel);

    btnChooseImage.setBackground(new Color(0, 153, 255));
    btnChooseImage.setForeground(Color.WHITE);
    btnChooseImage.setFocusPainted(false);

    int res = JOptionPane.showConfirmDialog(this, panel, "Add Room", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (res != JOptionPane.OK_OPTION) return;

    String roomNo = fRoomNo.getText().trim();
    String type = (String) fType.getSelectedItem();
    String priceS = fPrice.getText().trim();
    String desc = fDesc.getText().trim();
    String status = (String) fStatus.getSelectedItem();

    if (roomNo.isEmpty() || type.isEmpty() || priceS.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Fill all required fields.", "Validation", JOptionPane.WARNING_MESSAGE);
        return;
    }

    double price;
    try { price = Double.parseDouble(priceS); }
    catch (NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Invalid price.", "Validation", JOptionPane.WARNING_MESSAGE); return; }

    String imagePath = null;
    if (chosenFile[0] != null) {
        imagePath = copyImageToFolder(chosenFile[0]);
        if (imagePath == null) {
            JOptionPane.showMessageDialog(this, "Failed to save image.", "File Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
    }

    String sql = "INSERT INTO rooms(room_number, room_type, price, status, description, image_path) VALUES(?,?,?,?,?,?)";
    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql)) {
        pst.setString(1, roomNo);
        pst.setString(2, type);
        pst.setDouble(3, price);
        pst.setString(4, status);
        pst.setString(5, desc);
        pst.setString(6, imagePath);
        pst.executeUpdate();
        JOptionPane.showMessageDialog(this, "✅ Room added successfully!");
        loadRooms();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error adding room: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
    }
}

private void editRoom() {
    int sel = table.getSelectedRow();
    if (sel == -1) { JOptionPane.showMessageDialog(this, "Select a room to edit."); return; }

    int modelRow = table.convertRowIndexToModel(sel);
    int id = Integer.parseInt(model.getValueAt(modelRow, 0).toString());
    String curRoomNo = model.getValueAt(modelRow, 1).toString();
    String curType = model.getValueAt(modelRow, 2).toString();
    String curPrice = model.getValueAt(modelRow, 3).toString().replaceAll(",", "");
    String curStatus = model.getValueAt(modelRow, 4).toString();
    String curDesc = model.getValueAt(modelRow, 5) == null ? "" : model.getValueAt(modelRow, 5).toString();
    String curImage = model.getValueAt(modelRow, 6) == null ? null : model.getValueAt(modelRow, 6).toString();

    JTextField fRoomNo = new JTextField(curRoomNo);
    fRoomNo.setEditable(false);

    JComboBox<String> fType = new JComboBox<>(new String[]{"Suite", "Standard", "Deluxe"});
    fType.setSelectedItem(curType);

    JTextField fPrice = new JTextField(curPrice);
    JTextArea fDesc = new JTextArea(curDesc, 4, 20);
    JComboBox<String> fStatus = new JComboBox<>(new String[]{"Available", "Booked", "Unavailable"});
    fStatus.setSelectedItem(curStatus);

    fType.addActionListener(e -> {
        String type = (String) fType.getSelectedItem();
        switch (type) {
            case "Suite": fPrice.setText("5000"); break;
            case "Standard": fPrice.setText("2500"); break;
            case "Deluxe": fPrice.setText("3500"); break;
        }
    });

    JButton btnChooseImage = new JButton("🖼 Choose New Image");
    JLabel imgLabel = new JLabel(curImage == null ? "No image" : curImage);
    final File[] chosenFile = new File[1];

    btnChooseImage.addActionListener(e -> {
        JFileChooser fc = new JFileChooser();
        fc.setFileFilter(new javax.swing.filechooser.FileNameExtensionFilter("Image files", ImageIO.getReaderFileSuffixes()));
        int ok = fc.showOpenDialog(this);
        if (ok == JFileChooser.APPROVE_OPTION) {
            chosenFile[0] = fc.getSelectedFile();
            imgLabel.setText(chosenFile[0].getName());
        }
    });

    JPanel panel = new JPanel(new GridLayout(0, 2, 10, 10));
    panel.setBackground(new Color(245, 250, 255));
    panel.setBorder(BorderFactory.createTitledBorder(
        BorderFactory.createLineBorder(new Color(0, 153, 102), 2),
        "Edit Room Details",
        0, 0,
        new Font("Segoe UI", Font.BOLD, 18),
        new Color(0, 153, 102)
    ));

    Font labelFont = new Font("Segoe UI", Font.BOLD, 14);
    Color labelColor = new Color(40, 70, 60);

    JLabel lblRoom = new JLabel("Room #:");
    lblRoom.setForeground(labelColor); lblRoom.setFont(labelFont);
    JLabel lblType = new JLabel("Type:");
    lblType.setForeground(labelColor); lblType.setFont(labelFont);
    JLabel lblPrice = new JLabel("Price:");
    lblPrice.setForeground(labelColor); lblPrice.setFont(labelFont);
    JLabel lblStatus = new JLabel("Status:");
    lblStatus.setForeground(labelColor); lblStatus.setFont(labelFont);
    JLabel lblDesc = new JLabel("Description:");
    lblDesc.setForeground(labelColor); lblDesc.setFont(labelFont);

    panel.add(lblRoom); panel.add(fRoomNo);
    panel.add(lblType); panel.add(fType);
    panel.add(lblPrice); panel.add(fPrice);
    panel.add(lblStatus); panel.add(fStatus);
    panel.add(lblDesc); panel.add(new JScrollPane(fDesc));
    panel.add(btnChooseImage); panel.add(imgLabel);

    btnChooseImage.setBackground(new Color(0, 200, 120));
    btnChooseImage.setForeground(Color.WHITE);
    btnChooseImage.setFocusPainted(false);

    int res = JOptionPane.showConfirmDialog(this, panel, "Edit Room", JOptionPane.OK_CANCEL_OPTION, JOptionPane.PLAIN_MESSAGE);
    if (res != JOptionPane.OK_OPTION) return;

    String type = (String) fType.getSelectedItem();
    String priceS = fPrice.getText().trim();
    String desc = fDesc.getText().trim();
    String status = (String) fStatus.getSelectedItem();

    if (priceS.isEmpty()) {
        JOptionPane.showMessageDialog(this, "Price is required.", "Validation", JOptionPane.WARNING_MESSAGE);
        return;
    }

    double price;
    try { price = Double.parseDouble(priceS); }
    catch (NumberFormatException ex) { JOptionPane.showMessageDialog(this, "Invalid price.", "Validation", JOptionPane.WARNING_MESSAGE); return; }

    String imagePath = curImage;
    if (chosenFile[0] != null) {
        String newPath = copyImageToFolder(chosenFile[0]);
        if (newPath != null) {
            if (curImage != null) try { Files.deleteIfExists(Paths.get(curImage)); } catch (Exception ignored) {}
            imagePath = newPath;
        }
    }

    String sql = "UPDATE rooms SET room_type=?, price=?, status=?, description=?, image_path=? WHERE id=?";
    try (Connection con = DBConnection.getConnection();
         PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql)) {
        pst.setString(1, type);
        pst.setDouble(2, price);
        pst.setString(3, status);
        pst.setString(4, desc);
        pst.setString(5, imagePath);
        pst.setInt(6, id);
        pst.executeUpdate();
        JOptionPane.showMessageDialog(this, "✅ Room updated successfully!");
        loadRooms();
    } catch (SQLException ex) {
        JOptionPane.showMessageDialog(this, "Error updating room: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
    }
}


        private void deleteRoom() {
            int sel = table.getSelectedRow();
            if (sel == -1) { JOptionPane.showMessageDialog(this, "Select a room to delete."); return; }
            int modelRow = table.convertRowIndexToModel(sel);
            int id = Integer.parseInt(model.getValueAt(modelRow,0).toString());
            String imgPath = model.getValueAt(modelRow,6) == null ? null : model.getValueAt(modelRow,6).toString();

            int ok = JOptionPane.showConfirmDialog(this, "Delete selected room? This cannot be undone.", "Confirm Delete", JOptionPane.YES_NO_OPTION);
            if (ok != JOptionPane.YES_OPTION) return;

            try (Connection con = DBConnection.getConnection();
                 PreparedStatement pst = (PreparedStatement) con.prepareStatement("DELETE FROM rooms WHERE id=?")) {
                pst.setInt(1, id);
                pst.executeUpdate();
                if (imgPath != null) try { Files.deleteIfExists(Paths.get(imgPath)); } catch (Exception ignored) {}
                JOptionPane.showMessageDialog(this, "Room deleted.");
                loadRooms();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Error deleting room: " + ex.getMessage(), "DB Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void previewImage() {
            int sel = table.getSelectedRow();
            if (sel == -1) { JOptionPane.showMessageDialog(this, "Select a room to preview image."); return; }
            int modelRow = table.convertRowIndexToModel(sel);
            String path = model.getValueAt(modelRow,6) == null ? null : model.getValueAt(modelRow,6).toString();
            if (path == null) { JOptionPane.showMessageDialog(this, "No image for this room."); return; }
            try {
                BufferedImage img = ImageIO.read(new File(path));
                ImageIcon icon = new ImageIcon(img.getScaledInstance(500, 350, Image.SCALE_SMOOTH));
                JLabel lbl = new JLabel(icon);
                JOptionPane.showMessageDialog(this, lbl, "Room Image", JOptionPane.PLAIN_MESSAGE);
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Cannot load image: " + ex.getMessage(), "File Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        // copies the chosen image into a project images folder and returns saved path
        private String copyImageToFolder(File src) {
            try {
                Path imagesDir = Paths.get("images");
                if (Files.notExists(imagesDir)) Files.createDirectories(imagesDir);

                String ext = "";
                String name = src.getName();
                int i = name.lastIndexOf('.');
                if (i > 0) ext = name.substring(i);
                String newName = "room_" + System.currentTimeMillis() + "_" + UUID.randomUUID().toString().substring(0,6) + ext;
                Path dest = imagesDir.resolve(newName);
                Files.copy(src.toPath(), dest, StandardCopyOption.REPLACE_EXISTING);
                return dest.toString();
            } catch (IOException ex) {
                ex.printStackTrace();
                return null;
            }
        }

        public static void main(String[] args) {
            SwingUtilities.invokeLater(() -> new ManageRooms().setVisible(true));
        }
    }