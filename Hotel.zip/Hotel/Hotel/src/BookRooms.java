import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.io.File;
import javax.imageio.ImageIO;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class BookRooms extends JFrame {
    private Connection con;
    private JPanel panelRooms;
    private String loggedInUsername; // ✅ store logged-in username

    // ✅ constructor now requires username
    public BookRooms(String username) {
        this.loggedInUsername = username;

        setTitle("Book Rooms");
        setSize(950, 600);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        // Connect to database  
        con = DBConnection.getConnection();

        // ===== HEADER PANEL (with Back button) =====
        JPanel headerPanel = new JPanel(new BorderLayout());
        headerPanel.setBackground(new Color(66, 133, 244));
        headerPanel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        JButton btnBack = new JButton("← Back");
        btnBack.setBackground(Color.WHITE);
        btnBack.setForeground(new Color(66, 133, 244));
        btnBack.setFocusPainted(false);
        btnBack.setFont(new Font("Segoe UI", Font.BOLD, 13));

        // Go back to GuestDashboard
        btnBack.addActionListener(e -> {
            Window window = SwingUtilities.getWindowAncestor(btnBack);
            if (window != null) {
            window.dispose(); // ✅ force close entire BookRooms window
    }
            new GuestDashboard(username).setVisible(true);
        });

        JLabel lblTitle = new JLabel("Book Available Rooms", SwingConstants.CENTER);
        lblTitle.setFont(new Font("Segoe UI", Font.BOLD, 18));
        lblTitle.setForeground(Color.WHITE);

        headerPanel.add(btnBack, BorderLayout.WEST);
        headerPanel.add(lblTitle, BorderLayout.CENTER);

        add(headerPanel, BorderLayout.NORTH);

        // ===== MAIN CONTENT PANEL =====
        panelRooms = new JPanel(new GridLayout(0, 3, 10, 10));
        panelRooms.setBackground(new Color(245, 245, 245));

        JPanel centerPanel = new JPanel(new GridBagLayout());
        centerPanel.setBackground(new Color(245, 245, 245));
        centerPanel.add(panelRooms);

        JScrollPane scrollPane = new JScrollPane(centerPanel);
        scrollPane.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);

        add(scrollPane, BorderLayout.CENTER);

        loadRooms(panelRooms);

        setLocationRelativeTo(null);
        setVisible(true);
    }

    private void loadRooms(JPanel panelRooms) {
        try {
            String query = "SELECT * FROM rooms WHERE status = 'Available'";
            PreparedStatement pst = (PreparedStatement) con.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                int id = rs.getInt("id");
                String roomNumber = rs.getString("room_number");
                String roomType = rs.getString("room_type");
                double price = rs.getDouble("price");
                String description = rs.getString("description");
                String imagePath = rs.getString("image_path");

                JPanel roomCard = new JPanel(new BorderLayout());
                roomCard.setBackground(Color.WHITE);
                roomCard.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200), 1));
                roomCard.setPreferredSize(new Dimension(280, 300));

                JLabel lblImage = new JLabel();
                lblImage.setHorizontalAlignment(JLabel.CENTER);
                lblImage.setPreferredSize(new Dimension(250, 150));

                try {
                    if (imagePath != null && !imagePath.isEmpty()) {
                        Image img = ImageIO.read(new File(imagePath));
                        Image scaled = img.getScaledInstance(250, 150, Image.SCALE_SMOOTH);
                        lblImage.setIcon(new ImageIcon(scaled));
                    } else {
                        lblImage.setText("No Image");
                    }
                } catch (Exception ex) {
                    lblImage.setText("Error Loading Image");
                }

                JPanel infoPanel = new JPanel();
                infoPanel.setLayout(new BoxLayout(infoPanel, BoxLayout.Y_AXIS));
                infoPanel.setBackground(Color.WHITE);

                JLabel lblType = new JLabel("Type: " + roomType);
                JLabel lblPrice = new JLabel("Price: ₱" + price);
                JLabel lblNumber = new JLabel("Room No: " + roomNumber);

                lblType.setFont(new Font("Segoe UI", Font.BOLD, 14));
                lblPrice.setFont(new Font("Segoe UI", Font.PLAIN, 13));
                lblNumber.setFont(new Font("Segoe UI", Font.PLAIN, 13));

                infoPanel.add(lblType);
                infoPanel.add(lblNumber);
                infoPanel.add(lblPrice);

                JButton btnView = new JButton("View Details");
                btnView.setBackground(new Color(66, 133, 244));
                btnView.setForeground(Color.WHITE);
                btnView.setFocusPainted(false);
                
                // ✅ pass currentUsername to RoomDetailsDialog
                btnView.addActionListener(e -> {
                    new RoomDetailsDialog(this,loggedInUsername, id, roomNumber, roomType, price, description, imagePath);
                    
                });

                roomCard.add(lblImage, BorderLayout.NORTH);
                roomCard.add(infoPanel, BorderLayout.CENTER);
                roomCard.add(btnView, BorderLayout.SOUTH);

                panelRooms.add(roomCard);
            }

            panelRooms.revalidate();
            panelRooms.repaint();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, "Error loading rooms: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BookRooms("guest1")); // ✅ test with username
    }
}
