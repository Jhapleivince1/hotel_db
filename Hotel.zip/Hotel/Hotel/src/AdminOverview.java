import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.text.DecimalFormat;
import java.util.*; 
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;// ✅ Added for Stack, Queue, ArrayList

public class AdminOverview extends JFrame {
    private JLabel lblSales, lblReservations, lblGuests;
    private Connection con;

   
    private Stack<String> updateHistory;
    private Queue<String> recentActions;
    private String[] overviewLabels;
    private ArrayList<String> overviewData;

    public AdminOverview() {
        setTitle("Admin Overview");
        setSize(600, 400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        con = DBConnection.getConnection();

        
        updateHistory = new Stack<>();
        recentActions = new LinkedList<>();
        overviewLabels = new String[]{"Sales", "Reservations", "Guests"};
        overviewData = new ArrayList<>();

        JPanel mainPanel = new JPanel(new BorderLayout());
        mainPanel.setBackground(new Color(0, 153, 153));
        mainPanel.setBorder(BorderFactory.createEmptyBorder(20, 20, 20, 20));

        JLabel header = new JLabel("ADMIN OVERVIEW", SwingConstants.CENTER);
        header.setFont(new Font("Segoe UI", Font.BOLD, 28));
        header.setForeground(Color.WHITE);
        mainPanel.add(header, BorderLayout.NORTH);

        JPanel statsPanel = new JPanel(new GridLayout(3, 1, 15, 15));
        statsPanel.setBackground(new Color(0, 153, 153));

        lblSales = createStatLabel("Total Sales: ₱0.00");
        lblReservations = createStatLabel("Total Reservations: 0");
        lblGuests = createStatLabel("Total Guests: 0");

        statsPanel.add(lblSales);
        statsPanel.add(lblReservations);
        statsPanel.add(lblGuests);

        mainPanel.add(statsPanel, BorderLayout.CENTER);

        JPanel bottomPanel = new JPanel();
        bottomPanel.setBackground(new Color(0, 153, 153));

        JButton btnRefresh = new JButton("⟳ Refresh");
        JButton btnBack = new JButton("← Back to Dashboard");

        styleButton(btnRefresh, new Color(0, 102, 102));
        styleButton(btnBack, new Color(153, 0, 0));

        btnRefresh.addActionListener(e -> {
            loadOverviewData();
            // ✅ Add to queue and stack for history
            recentActions.offer("Refreshed overview");
            updateHistory.push("Data refreshed at " + new java.util.Date());
        });

        btnBack.addActionListener(e -> {
            new admin().setVisible(true);
            dispose();
        });

        bottomPanel.add(btnRefresh);
        bottomPanel.add(btnBack);
        mainPanel.add(bottomPanel, BorderLayout.SOUTH);

        add(mainPanel);
        loadOverviewData();
    }

    private JLabel createStatLabel(String text) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Segoe UI", Font.BOLD, 22));
        label.setForeground(Color.WHITE);
        label.setOpaque(true);
        label.setBackground(new Color(0, 102, 102));
        label.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(Color.WHITE, 2),
            BorderFactory.createEmptyBorder(10, 10, 10, 10)
        ));
        return label;
    }

    private void styleButton(JButton btn, Color bg) {
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btn.setBackground(bg);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));
        btn.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                btn.setBackground(bg.darker());
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                btn.setBackground(bg);
            }
        });
    }

    private void loadOverviewData() {
        if (con == null) {
            JOptionPane.showMessageDialog(this, "Database connection failed!");
            return;
        }

        DecimalFormat df = new DecimalFormat("#,##0.00");

        try {
            // Total Sales
            PreparedStatement pstSales = (PreparedStatement) con.prepareStatement(
                "SELECT SUM(total_amount) AS total_sales FROM guest_reservations WHERE status='Booked'"
            );
            ResultSet rsSales = pstSales.executeQuery();
            if (rsSales.next()) {
                double totalSales = rsSales.getDouble("total_sales");
                lblSales.setText("Total Sales: ₱" + df.format(totalSales));

                // ✅ Store in ArrayList
                overviewData.add("Sales: ₱" + df.format(totalSales));
            }
            rsSales.close();
            pstSales.close();

            // Total Reservations
            PreparedStatement pstRes = (PreparedStatement) con.prepareStatement(
                "SELECT COUNT(*) AS total_res FROM guest_reservations"
            );
            ResultSet rsRes = pstRes.executeQuery();
            if (rsRes.next()) {
                lblReservations.setText("Total Reservations: " + rsRes.getInt("total_res"));

                // ✅ Store in ArrayList
                overviewData.add("Reservations: " + rsRes.getInt("total_res"));
            }
            rsRes.close();
            pstRes.close();

            
            PreparedStatement pstGuests = (PreparedStatement) con.prepareStatement(
                "SELECT COUNT(*) AS total_guests FROM user"
            );
            ResultSet rsGuests = pstGuests.executeQuery();
            if (rsGuests.next()) {
                lblGuests.setText("Total Guests: " + rsGuests.getInt("total_guests"));

                
                overviewData.add("Guests: " + rsGuests.getInt("total_guests"));
            }
            rsGuests.close();
            pstGuests.close();

            
            System.out.println("\n--- Array Example ---");
            for (String label : overviewLabels) {
                System.out.println("Label: " + label);
            }

            System.out.println("\n--- ArrayList Example ---");
            for (String data : overviewData) {
                System.out.println(data);
            }

            System.out.println("\n--- Stack Example ---");
            System.out.println("Last action: " + (updateHistory.isEmpty() ? "None" : updateHistory.peek()));

            System.out.println("\n--- Queue Example ---");
            System.out.println("Next action in queue: " + (recentActions.isEmpty() ? "None" : recentActions.peek()));

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading overview: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new AdminOverview().setVisible(true));
    }
}
