import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class ArchivedGuests extends JFrame {

    private JTable table;
    private DefaultTableModel model;
    private JButton btnRefresh, btnClose;

    public ArchivedGuests() {
        setTitle("Archived Guests");
        setSize(950, 520);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 245, 245));

        // === Table setup ===
        model = new DefaultTableModel(
            new String[]{"Archive ID", "Reservation ID", "Username", "Room No", "Check-In", "Check-Out", "Status", "Archived At"}, 
            0
        ) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setRowHeight(28);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Archived Guest Reservations"));
        add(scrollPane, BorderLayout.CENTER);

        // === Buttons ===
        JPanel panelButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        Color mainColor = new Color(0, 102, 102);

        btnRefresh = createButton("Refresh", mainColor);
        btnClose = createButton("Close", new Color(153, 0, 0));

        panelButtons.add(btnRefresh);
        panelButtons.add(btnClose);
        add(panelButtons, BorderLayout.SOUTH);

        // === Button actions ===
        btnRefresh.addActionListener(e -> loadArchivedGuests());
        btnClose.addActionListener(e -> dispose());

        // === Load data initially ===
        loadArchivedGuests();
    }

    private JButton createButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        return btn;
    }

    private void loadArchivedGuests() {
        model.setRowCount(0);
        String sql = """
            SELECT id, reservation_id, username, room_number, checkin_date, checkout_date, status, archived_at
            FROM archived_guests
            ORDER BY archived_at DESC
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                        rs.getInt("id"),
                        rs.getInt("reservation_id"),
                        rs.getString("username"),
                        rs.getString("room_number"),
                        rs.getString("checkin_date"),
                        rs.getString("checkout_date"),
                        rs.getString("status"),
                        rs.getTimestamp("archived_at")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading archived guests: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ArchivedGuests().setVisible(true));
    }
}
