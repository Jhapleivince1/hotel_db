import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.*;
import java.sql.Statement;
import com.mysql.jdbc.PreparedStatement;

public class ManageGuest extends JFrame {
    private JTable table;
    private DefaultTableModel model;
    private JButton btnArchive, btnViewArchives, btnRefresh, btnBack;

    public ManageGuest() {
        setTitle("Manage Guests");
        setSize(950, 520);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(new Color(245, 245, 245));

        // === Table setup ===
        model = new DefaultTableModel(
            new String[]{"Reservation ID", "Guest Username", "Room No", "Check-in", "Check-out", "Status"}, 0
        ) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };

        table = new JTable(model);
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setRowHeight(28);

        JScrollPane scrollPane = new JScrollPane(table);
        scrollPane.setBorder(BorderFactory.createTitledBorder("Guest Reservations"));
        add(scrollPane, BorderLayout.CENTER);

        // === Buttons ===
        JPanel panelButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 10));
        Color mainColor = new Color(0, 102, 102);

        btnArchive = createButton("Archive Guest", mainColor);
        btnViewArchives = createButton("View Archives", mainColor);
        btnRefresh = createButton("Refresh", mainColor);
        btnBack = createButton("← Back", new Color(153, 0, 0));

        panelButtons.add(btnArchive);
        panelButtons.add(btnViewArchives);
        panelButtons.add(btnRefresh);
        panelButtons.add(btnBack);

        add(panelButtons, BorderLayout.SOUTH);

        // === Button actions ===
        btnArchive.addActionListener(e -> archiveSelectedGuest());
        btnRefresh.addActionListener(e -> loadGuests());
        btnViewArchives.addActionListener(e -> new ArchivedGuests().setVisible(true));
        btnBack.addActionListener(e -> {
            new admin().setVisible(true);
            dispose();
        });

        loadGuests();
    }

    private JButton createButton(String text, Color color) {
        JButton btn = new JButton(text);
        btn.setBackground(color);
        btn.setForeground(Color.WHITE);
        btn.setFocusPainted(false);
        btn.setFont(new Font("Segoe UI", Font.BOLD, 14));
        return btn;
    }

    // ✅ LOAD GUESTS FROM guest_reservations TABLE
    private void loadGuests() {
        model.setRowCount(0);
        String sql = """
            SELECT id, username, room_number, checkin_date, checkout_date, status
            FROM guest_reservations
            ORDER BY checkin_date DESC
        """;

        try (Connection con = DBConnection.getConnection();
             PreparedStatement pst = (PreparedStatement) con.prepareStatement(sql);
             ResultSet rs = pst.executeQuery()) {

            while (rs.next()) {
                model.addRow(new Object[]{
                    rs.getInt("id"),
                    rs.getString("username"),
                    rs.getString("room_number"),
                    rs.getString("checkin_date"),
                    rs.getString("checkout_date"),
                    rs.getString("status")
                });
            }

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error loading guests: " + e.getMessage());
        }
    }

    // ✅ ARCHIVE FUNCTION (MOVE FROM guest_reservations → archived_guests)
    private void archiveSelectedGuest() {
        int row = table.getSelectedRow();
        if (row == -1) {
            JOptionPane.showMessageDialog(this, "Select a guest to archive.");
            return;
        }

        int id = (int) model.getValueAt(row, 0);
        String guestUsername = model.getValueAt(row, 1).toString();
        int confirm = JOptionPane.showConfirmDialog(
            this, "Archive reservation of " + guestUsername + "?", "Confirm", JOptionPane.YES_NO_OPTION
        );
        if (confirm != JOptionPane.YES_OPTION) return;

        try (Connection con = DBConnection.getConnection()) {
            // Move data to archive table
            String insert = """
                INSERT INTO archived_guests (reservation_id, username, room_number, checkin_date, checkout_date, status)
                SELECT id, username, room_number, checkin_date, checkout_date, status
                FROM guest_reservations
                WHERE id = ?
            """;
            PreparedStatement pstInsert = (PreparedStatement) con.prepareStatement(insert);
            pstInsert.setInt(1, id);
            pstInsert.executeUpdate();

            // Delete from active reservations
            String delete = "DELETE FROM guest_reservations WHERE id = ?";
            PreparedStatement pstDel = (PreparedStatement) con.prepareStatement(delete);
            pstDel.setInt(1, id);
            pstDel.executeUpdate();

            JOptionPane.showMessageDialog(this, "Guest archived successfully!");
            loadGuests();

        } catch (SQLException e) {
            JOptionPane.showMessageDialog(this, "Error archiving guest: " + e.getMessage());
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ManageGuest().setVisible(true));
    }
}
